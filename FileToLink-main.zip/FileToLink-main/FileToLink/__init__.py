from FileToLink.config import Config, Strings
from FileToLink.client import bot
